﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiLink.Api
{
    public class AppSettings
    {
        public const string Service_Config = "Service_Config";
        public const string MULTILINK__URL = "MULTILINK__URL";
        public const string HEADER_USER_ID = "HEADER_USER_ID";
        public const string HEADER_PASSWORD = "HEADER_PASSWORD";
        public const string HEADER_IP_ADDRESS = "HEADER_IP_ADDRESS";
        public const string HEADER_REQUEST_ID = "HEADER_REQUEST_ID";
        public const string HEADER_IMEI_NUMBER = "HEADER_IMEI_NUMBER";
        public const string IS_LOGGER = "IS_LOGGER";
    }
}
