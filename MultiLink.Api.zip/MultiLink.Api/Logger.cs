﻿using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Xml;

namespace MultiLink.Api
{
    public static class Logger
    {
        static Logger()
        {
            log4net.Config.XmlConfigurator.Configure();
        }

        public static void Debug(string message)
        {
            ILog logger = log4net.LogManager.GetLogger("ErrorLog");
            logger.Error(message);
        }
    }
}
