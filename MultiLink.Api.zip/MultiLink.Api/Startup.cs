using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace MultiLink.Api
{
    public class Startup
    {
        public static IDictionary<string, string> AppSetting = new Dictionary<string, string>();
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            #region  ADD JSON OPTIONS GO IN .NET CORE 3.0?
            services.AddMvc().AddJsonOptions(o => { o.JsonSerializerOptions.PropertyNamingPolicy = null; o.JsonSerializerOptions.DictionaryKeyPolicy = null; });
            #endregion

            #region REGISTER THE SWAGGER SERVICES
            services.AddMvc();

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "MultiLink", Version = "v1", Description = "MultiLink Service API", });
            });

            services.AddMvcCore().AddApiExplorer();
            #endregion

            #region SET ALL APP SETTING URL
            AppSetting.Add(AppSettings.MULTILINK__URL, Configuration.GetSection(AppSettings.Service_Config).GetSection(AppSettings.MULTILINK__URL).Value);
            AppSetting.Add(AppSettings.HEADER_USER_ID, Configuration.GetSection(AppSettings.Service_Config).GetSection(AppSettings.HEADER_USER_ID).Value);
            AppSetting.Add(AppSettings.HEADER_PASSWORD, Configuration.GetSection(AppSettings.Service_Config).GetSection(AppSettings.HEADER_PASSWORD).Value);
            AppSetting.Add(AppSettings.HEADER_IP_ADDRESS, Configuration.GetSection(AppSettings.Service_Config).GetSection(AppSettings.HEADER_IP_ADDRESS).Value);
            AppSetting.Add(AppSettings.HEADER_REQUEST_ID, Configuration.GetSection(AppSettings.Service_Config).GetSection(AppSettings.HEADER_REQUEST_ID).Value);
            AppSetting.Add(AppSettings.HEADER_IMEI_NUMBER, Configuration.GetSection(AppSettings.Service_Config).GetSection(AppSettings.HEADER_IMEI_NUMBER).Value);
            AppSetting.Add(AppSettings.IS_LOGGER, Configuration.GetSection(AppSettings.Service_Config).GetSection(AppSettings.IS_LOGGER).Value);
            #endregion
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env,ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            #region ADD LOG4 NET
            loggerFactory.AddLog4Net();
            #endregion

            #region REGISTER THE SWAGGER GENERATOR AND THE SWAGGER UI MIDDLE WARES
            app.UseSwagger();
            app.UseSwaggerUI(c => { c.SwaggerEndpoint("../swagger/v1/swagger.json", "MultiLink.core v1"); });
            #endregion

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
