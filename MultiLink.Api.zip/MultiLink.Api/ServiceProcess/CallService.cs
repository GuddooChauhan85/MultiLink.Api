﻿using MultiLink.Api.Model;
using MultiLink.Api.Utility;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiLink.Api.ServiceProcess
{
    public class CallService
    {

        #region 01 AIR SEARCH
        public async Task<AirFareRuleRes> airSearch(AirSearchReq airSearchReq)
        {
            var airSearchRes = new AirFareRuleRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airSearchRequest = JsonConvert.DeserializeObject<AirSearchRequest>(JsonConvert.SerializeObject(airSearchReq));
            airSearchRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_Search, JsonConvert.SerializeObject(airSearchRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airSearchRes = JsonConvert.DeserializeObject<AirFareRuleRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airSearchRes = new AirFareRuleRes() {Response_Header=new ResponseHeader() {Error_Code= ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc=ex.Message,Error_InnerException=ex.Message } };
            }
            return await Task.FromResult(airSearchRes);
        }
        #endregion

        #region 02 AIR_FARE_RULE
        public async Task<AirFareRuleDataRes> airFareRule(AirFareRuleReq airFareRuleReq)
        {
            var airFareRuleDataRes = new AirFareRuleDataRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airFareRuleRequest = JsonConvert.DeserializeObject<AirFareRuleRequest>(JsonConvert.SerializeObject(airFareRuleReq));
            airFareRuleRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_FareRule, JsonConvert.SerializeObject(airFareRuleRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airFareRuleDataRes = JsonConvert.DeserializeObject<AirFareRuleDataRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airFareRuleDataRes = new AirFareRuleDataRes() {Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airFareRuleDataRes);
        }
        #endregion

        #region 03 AIR REPRICE
        public async Task<AirRepriceRes> airReprice(AirRepriceReq airRepriceReq)
        {
            var airRepriceRes = new AirRepriceRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airRepriceRequest = JsonConvert.DeserializeObject<AirRepriceRequest>(JsonConvert.SerializeObject(airRepriceReq));
            airRepriceRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_Reprice, JsonConvert.SerializeObject(airRepriceRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airRepriceRes = JsonConvert.DeserializeObject<AirRepriceRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airRepriceRes = new AirRepriceRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airRepriceRes);
        }
        #endregion

        #region 04 AIR_GET SSR
        public async Task<AirGetSSRRes> airGetSSR(AirGetSSRReq airGetSSRReq)
        {
            var airGetSSRRes = new AirGetSSRRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airGetSSRRequest = JsonConvert.DeserializeObject<AirGetSSRRequest>(JsonConvert.SerializeObject(airGetSSRReq));
            airGetSSRRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_Reprice, JsonConvert.SerializeObject(airGetSSRRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airGetSSRRes = JsonConvert.DeserializeObject<AirGetSSRRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airGetSSRRes = new AirGetSSRRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airGetSSRRes);
        }
        #endregion

        #region 05 AIR GET SEAT MAP
        public async Task<AirGetSeatMapRes> airGetSeatMap(AirGetSeatMapReq airGetSeatMapReq)
        {
            var airGetSeatMapRes = new AirGetSeatMapRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airGetSeatMapRequest = JsonConvert.DeserializeObject<AirGetSeatMapRequest>(JsonConvert.SerializeObject(airGetSeatMapReq));
            airGetSeatMapRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_GetSeatMap, JsonConvert.SerializeObject(airGetSeatMapRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airGetSeatMapRes = JsonConvert.DeserializeObject<AirGetSeatMapRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airGetSeatMapRes = new AirGetSeatMapRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airGetSeatMapRes);
        }
        #endregion

        #region 06 AIR_TEMP BOOKING
        public async Task<AirTempBookingBookingRes> airTempBooking(AirTempBookingReq airTempBookingReq)
        {
            var airTempBookingBookingRes = new AirTempBookingBookingRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airTempBookingRequest = JsonConvert.DeserializeObject<AirTempBookingRequest>(JsonConvert.SerializeObject(airTempBookingReq));
            airTempBookingRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_TempBooking, JsonConvert.SerializeObject(airTempBookingRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airTempBookingBookingRes = JsonConvert.DeserializeObject<AirTempBookingBookingRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airTempBookingBookingRes = new AirTempBookingBookingRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airTempBookingBookingRes);
        }
        #endregion

        #region 07 AIR_TICKETING
        public async Task<AirTicketingRes> airTicketing(AirTicketingReq airTicketingReq)
        {
            var airTicketingRes = new AirTicketingRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airTicketingRequest = JsonConvert.DeserializeObject<AirTicketingRequest>(JsonConvert.SerializeObject(airTicketingReq));
            airTicketingRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_Ticketing, JsonConvert.SerializeObject(airTicketingRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airTicketingRes = JsonConvert.DeserializeObject<AirTicketingRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airTicketingRes = new AirTicketingRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airTicketingRes);
        }
        #endregion

        #region 08 AIR_HISTORY
        public async Task<AirHistoryRes> airHistory(AirHistoryReq airHistoryReq)
        {
            var airHistoryRes = new AirHistoryRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airHistoryRequset = JsonConvert.DeserializeObject<AirHistoryRequset>(JsonConvert.SerializeObject(airHistoryReq));
            airHistoryRequset.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_History, JsonConvert.SerializeObject(airHistoryRequset));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airHistoryRes = JsonConvert.DeserializeObject<AirHistoryRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airHistoryRes = new AirHistoryRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airHistoryRes);
        }
        #endregion

        #region 09 AIR_REPRINT
        public async Task<AirReprintRes> airReprint(AirReprintReq airReprintReq)
        {
            var airReprintRes = new AirReprintRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airReprintRequest = JsonConvert.DeserializeObject<AirReprintRequest>(JsonConvert.SerializeObject(airReprintReq));
            airReprintRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_Reprint, JsonConvert.SerializeObject(airReprintRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airReprintRes = JsonConvert.DeserializeObject<AirReprintRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airReprintRes = new AirReprintRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airReprintRes);
        }
        #endregion

        #region 10 AIR_TICKET CANCELLATION
        public async Task<AirTicketCancellationRes> airTicketCancellation(AirTicketCancellationReq airTicketCancellationReq)
        {
            var airTicketCancellationRes = new AirTicketCancellationRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airTicketCancellationRequest = JsonConvert.DeserializeObject<AirTicketCancellationRequest>(JsonConvert.SerializeObject(airTicketCancellationReq));
            airTicketCancellationRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_TicketCancellation, JsonConvert.SerializeObject(airTicketCancellationRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airTicketCancellationRes = JsonConvert.DeserializeObject<AirTicketCancellationRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airTicketCancellationRes = new AirTicketCancellationRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airTicketCancellationRes);
        }
        #endregion

        #region 11 AIR_LOW FARE
        public async Task<AirLowFareRes> airLowFare(AirLowFareReq airLowFareReq)
        {
            var airLowFareRes = new AirLowFareRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var airLowFareRequest = JsonConvert.DeserializeObject<AirLowFareRequest>(JsonConvert.SerializeObject(airLowFareReq));
            airLowFareRequest.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.Air_LowFare, JsonConvert.SerializeObject(airLowFareRequest));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    airLowFareRes = JsonConvert.DeserializeObject<AirLowFareRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                airLowFareRes = new AirLowFareRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(airLowFareRes);
        }
        #endregion

        #region 11 GET BALANCE
        public async Task<GetBalanceRes> getBalance(GetBalanceReq getBalanceReq)
        {
            var getBalanceRes = new GetBalanceRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var getBalanceRequset = JsonConvert.DeserializeObject<GetBalanceRequset>(JsonConvert.SerializeObject(getBalanceReq));
            getBalanceRequset.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.GetBalance, JsonConvert.SerializeObject(getBalanceRequset));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    getBalanceRes = JsonConvert.DeserializeObject<GetBalanceRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                getBalanceRes = new GetBalanceRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(getBalanceRes);
        }
        #endregion

        #region ADD PAYMENT
        public async Task<AddPaymentRes> addPayment(AddPaymentReq addPaymentReq)
        {
            var addPaymentRes = new AddPaymentRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.UNABLE_TO_DATA_CODE, Error_Desc = ServiceMessage.UNABLE_TO_DATA, Error_InnerException = ServiceMessage.UNABLE_TO_DATA } };

            string response = string.Empty;

            #region ALL REQUEST PARAM
            var addPaymentRequset = JsonConvert.DeserializeObject<AddPaymentRequset>(JsonConvert.SerializeObject(addPaymentReq));
            addPaymentRequset.Auth_Header = new AuthHeader()
            {
                IMEI_Number = Startup.AppSetting[AppSettings.HEADER_IMEI_NUMBER],
                IP_Address = Startup.AppSetting[AppSettings.HEADER_IP_ADDRESS],
                Password = Startup.AppSetting[AppSettings.HEADER_PASSWORD],
                Request_Id = Startup.AppSetting[AppSettings.HEADER_REQUEST_ID],
                UserId = Startup.AppSetting[AppSettings.HEADER_USER_ID],
            };
            #endregion
            try
            {
                response = new Util().HttpPostWithPara(Startup.AppSetting[AppSettings.MULTILINK__URL], MultiLink_Method_Name.AddPayment, JsonConvert.SerializeObject(addPaymentRequset));
                if (!string.IsNullOrEmpty(response) || Convert.ToString(response) != "")
                {

                    addPaymentRes = JsonConvert.DeserializeObject<AddPaymentRes>(Convert.ToString(response));
                }
            }
            catch (Exception ex)
            {
                addPaymentRes = new AddPaymentRes() { Response_Header = new ResponseHeader() { Error_Code = ServiceCODE.EXCEPTION_ERROR_Code, Error_Desc = ex.Message, Error_InnerException = ex.Message } };
            }
            return await Task.FromResult(addPaymentRes);
        }
        #endregion
    }
}
