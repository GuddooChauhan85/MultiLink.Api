﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiLink.Api.Model
{
    public class ServiceResponse
    {
    }


    #region SERVICE MESSAGE/SERVICE MESSAGE CODE
    public class ServiceMessage
    {
        public const string UNABLE_TO_DATA = "Unable to data";
    }

    public class ServiceCODE
    {
        public const string UNABLE_TO_DATA_CODE = "20000";
        public const string EXCEPTION_ERROR_Code = "500";
    }
    #endregion
}
