﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiLink.Api.Model
{
    public class ReqRes
    {
    }
    #region AUTH HEADER REQ
    public class AuthHeader
    {
        public string UserId { get; set; }
        public string Password { get; set; }
        public string IP_Address { get; set; }
        public string Request_Id { get; set; }
        public string IMEI_Number { get; set; }
    }
    #endregion

    #region RESPONSE HEADER RES
    public class ResponseHeader
    {
        public string Error_Code { get; set; }
        public string Error_Desc { get; set; }
        public string Error_InnerException { get; set; }
        public string Request_Id { get; set; }
        public string Status_Id { get; set; }
    }
    #endregion

    #region PAX DETAIL REQ
    public class PAXDetail
    {
        public int Pax_Id { get; set; }
        public int Pax_type { get; set; }
        public string Title { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public int Gender { get; set; }
        public string Age { get; set; }
        public string DOB { get; set; }
        public string Passport_Number { get; set; }
        public string Passport_Issuing_Country { get; set; }
        public string Passport_Expiry { get; set; }
        public string Nationality { get; set; }
        public string FrequentFlyerDetails { get; set; }
    }
    #endregion

    #region AIRPORT TAX
    public class AirportTax
    {
        public int Tax_Amount { get; set; }
        public string Tax_Code { get; set; }
        public string Tax_Desc { get; set; }
    }
    #endregion

    #region FARE CLASS
    public class FareClass
    {
        public string Class_Code { get; set; }
        public string Class_Desc { get; set; }
        public string FareBasis { get; set; }
        public string Privileges { get; set; }
        public int Segment_Id { get; set; }
    }
    #endregion

    #region FREE BAGGAGE
    public class FreeBaggage
    {
        public string Check_In_Baggage { get; set; }
        public string Hand_Baggage { get; set; }
    }
    #endregion

    #region RESCHEDULE CHARGE
    public class RescheduleCharge
    {
        public int Applicablility { get; set; }
        public int DurationFrom { get; set; }
        public int DurationTo { get; set; }
        public int DurationTypeFrom { get; set; }
        public int DurationTypeTo { get; set; }
        public int OfflineServiceFee { get; set; }
        public int OnlineServiceFee { get; set; }
        public int PassengerType { get; set; }
        public string Remarks { get; set; }
        public bool Return_Flight { get; set; }
        public string Value { get; set; }
        public int ValueType { get; set; }
    }
    #endregion

    #region FARE
    public class Fare
    {
        public List<FareDetail> FareDetails { get; set; }
        public int FareType { get; set; }
        public object Fare_Id { get; set; }
        public object Fare_Key { get; set; }
        public string Food_onboard { get; set; }
        public bool GSTMandatory { get; set; }
        public object LastFewSeats { get; set; }
        public string ProductClass { get; set; }
        public object PromptMessage { get; set; }
        public bool Refundable { get; set; }
        public object Seats_Available { get; set; }
        public string Warning { get; set; }
    }
    #endregion

    #region FARE DETAIL
    public class FareDetail
    {
        public int AirportTax_Amount { get; set; }
        public List<AirportTax> AirportTaxes { get; set; }
        public int Basic_Amount { get; set; }
        public List<CancellationCharge> CancellationCharges { get; set; }
        public string Currency_Code { get; set; }
        public List<FareClass> FareClasses { get; set; }
        public FreeBaggage Free_Baggage { get; set; }
        public int GST { get; set; }
        public int Gross_Commission { get; set; }
        public int Net_Commission { get; set; }
        public int PAX_Type { get; set; }
        public int Promo_Discount { get; set; }
        public List<RescheduleCharge> RescheduleCharges { get; set; }
        public int Service_Fee_Amount { get; set; }
        public int TDS { get; set; }
        public int Total_Amount { get; set; }
        public int Trade_Markup_Amount { get; set; }
        public int YQ_Amount { get; set; }
    }
    #endregion

    #region SEGMENT
    public class Segment
    {
        public string Aircraft_Type { get; set; }
        public string Airline_Code { get; set; }
        public string Airline_Name { get; set; }
        public string Arrival_DateTime { get; set; }
        public string Departure_DateTime { get; set; }
        public string Destination { get; set; }
        public object Destination_City { get; set; }
        public string Destination_Terminal { get; set; }
        public string Duration { get; set; }
        public string Flight_Number { get; set; }
        public int Leg_Index { get; set; }
        public string Origin { get; set; }
        public object Origin_City { get; set; }
        public string Origin_Terminal { get; set; }
        public bool Return_Flight { get; set; }
        public int Segment_Id { get; set; }
        public object Stop_Over { get; set; }
    }
    #endregion

    #region FLIGHT
    public class Flight
    {
        public string Airline_Code { get; set; }
        public bool Block_Ticket_Allowed { get; set; }
        public bool Cached { get; set; }
        public string Destination { get; set; }
        public List<Fare> Fares { get; set; }
        public string Flight_Id { get; set; }
        public string Flight_Key { get; set; }
        public object Flight_Numbers { get; set; }
        public bool GST_Entry_Allowed { get; set; }
        public bool HasMoreClass { get; set; }
        public int InventoryType { get; set; }
        public bool IsLCC { get; set; }
        public string Origin { get; set; }
        public bool Repriced { get; set; }
        public List<Segment> Segments { get; set; }
        public string TravelDate { get; set; }
    }
    #endregion

    #region 01 FLIGHT AVAILIBILITY REQ/RES

    #region FLIGHT AVAILIBILITY REQ
    public class AuthHeader_OLD
    {
        public string UserId { get; set; }
        public string Password { get; set; }
        public string IP_Address { get; set; }
        public string Request_Id { get; set; }
        public string IMEI_Number { get; set; }
    }
    public class TripInfo
    {
        public string Origin { get; set; }
        public string Destination { get; set; }
        public string TravelDate { get; set; }
        public int Trip_Id { get; set; }
    }
    public class FilteredAirline
    {
        public string Airline_Code { get; set; }
    }
    public class AirSearchReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public int Travel_Type { get; set; }
        public int Booking_Type { get; set; }
        public List<TripInfo> TripInfo { get; set; }
        public string Adult_Count { get; set; }
        public string Child_Count { get; set; }
        public string Infant_Count { get; set; }
        public string Class_Of_Travel { get; set; }
        public int InventoryType { get; set; }
        public List<FilteredAirline> Filtered_Airline { get; set; }
    }
    public class AirSearchRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public int Travel_Type { get; set; }
        public int Booking_Type { get; set; }
        public List<TripInfo> TripInfo { get; set; }
        public string Adult_Count { get; set; }
        public string Child_Count { get; set; }
        public string Infant_Count { get; set; }
        public string Class_Of_Travel { get; set; }
        public int InventoryType { get; set; }
        public List<FilteredAirline> Filtered_Airline { get; set; }
    }
    #endregion

    #region FLIGHT AVAILIBILITY RES
    public class AirFareRuleRes
    {
        public ResponseHeader Response_Header { get; set; }
        public string Search_Key { get; set; }
        public List<AirSearchTripDetail> TripDetails { get; set; }
    }
    public class AirSearchAirportTax
    {
        public decimal Tax_Amount { get; set; }
        public string Tax_Code { get; set; }
        public string Tax_Desc { get; set; }
    }
    public class AirSearchCancellationCharge
    {
        public int Applicablility { get; set; }
        public int DurationFrom { get; set; }
        public int DurationTo { get; set; }
        public int DurationTypeFrom { get; set; }
        public int DurationTypeTo { get; set; }
        public int OfflineServiceFee { get; set; }
        public int OnlineServiceFee { get; set; }
        public int PassengerType { get; set; }
        public object Remarks { get; set; }
        public bool Return_Flight { get; set; }
        public string Value { get; set; }
        public int ValueType { get; set; }
    }
    public class AirSearchFare
    {
        public List<FareDetail> FareDetails { get; set; }
        public int FareType { get; set; }
        public string Fare_Id { get; set; }
        public string Fare_Key { get; set; }
        public string Food_onboard { get; set; }
        public bool GSTMandatory { get; set; }
        public string LastFewSeats { get; set; }
        public string ProductClass { get; set; }
        public string PromptMessage { get; set; }
        public bool Refundable { get; set; }
        public string Seats_Available { get; set; }
        public string Warning { get; set; }
    }
    public class AirSearchFlight
    {
        public string Airline_Code { get; set; }
        public bool Block_Ticket_Allowed { get; set; }
        public bool Cached { get; set; }
        public string Destination { get; set; }
        public List<AirSearchFare> Fares { get; set; }
        public string Flight_Id { get; set; }
        public string Flight_Key { get; set; }
        public string Flight_Numbers { get; set; }
        public bool GST_Entry_Allowed { get; set; }
        public bool HasMoreClass { get; set; }
        public int InventoryType { get; set; }
        public bool IsLCC { get; set; }
        public string Origin { get; set; }
        public bool Repriced { get; set; }
        public List<Segment> Segments { get; set; }
        public string TravelDate { get; set; }
    }
    public class AirSearchTripDetail
    {
        public List<AirSearchFlight> Flights { get; set; }
        public int Trip_Id { get; set; }
    }

    #endregion

    #endregion

    #region 02 AIR FARE RULE REQ/RES

    #region AIR FARE RULE REQ
    public class AirFareRuleReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string Search_Key { get; set; }
        public string Flight_Key { get; set; }
        public string Fare_Id { get; set; }
    }
    public class AirFareRuleRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public string Search_Key { get; set; }
        public string Flight_Key { get; set; }
        public string Fare_Id { get; set; }
    }
    #endregion

    #region AIR FARE RULE RES
    public class AirFareFareRule
    {
        public string FareRuleDesc { get; set; }
        public string FareRuleName { get; set; }
        public string Segment_Id { get; set; }
    }
    public class AirFareRuleDataRes
    {
        public List<AirFareFareRule> FareRules { get; set; }
        public ResponseHeader Response_Header { get; set; }
    }
    #endregion

    #endregion

    #region 03 AIR REPRICE REQ/RES

    #region 03 AIR REPRICE REQ
    public class AirRepriceRequestData
    {
        public string Flight_Key { get; set; }
        public string Fare_Id { get; set; }
    }
    public class AirRepriceReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string Search_Key { get; set; }
        public List<AirRepriceRequestData> AirRepriceRequests { get; set; }
        public string Customer_Mobile { get; set; }
        public bool GST_Input { get; set; }
        public bool SinglePricing { get; set; }
    }
    public class AirRepriceRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public string Search_Key { get; set; }
        public List<AirRepriceRequestData> AirRepriceRequests { get; set; }
        public string Customer_Mobile { get; set; }
        public bool GST_Input { get; set; }
        public bool SinglePricing { get; set; }
    }
    #endregion

    #region 03 AIR REPRICE REQ/RES
    public class AirRepriceRes
    {
        public List<AirRepriceRespons> AirRepriceResponses { get; set; }
        public ResponseHeader Response_Header { get; set; }
    }
    public class RequiredPAXDetail
    {
        public bool Age { get; set; }
        public bool DOB { get; set; }
        public bool DefenceExpiryDate { get; set; }
        public bool DefenceIssueDate { get; set; }
        public bool DefenceServiceId { get; set; }
        public bool First_Name { get; set; }
        public bool Gender { get; set; }
        public bool Last_Name { get; set; }
        public string Mandatory_SSRs { get; set; }
        public bool Nationality { get; set; }
        public bool Passport_Expiry { get; set; }
        public bool Passport_Issuing_Country { get; set; }
        public bool Passport_Number { get; set; }
        public int Pax_type { get; set; }
        public bool Student_Id { get; set; }
        public bool Title { get; set; }
    }
    public class AirRepriceRespons
    {
        public Flight Flight { get; set; }
        public bool Frequent_Flyer_Accepted { get; set; }
        public List<RequiredPAXDetail> Required_PAX_Details { get; set; }
    }
    #endregion

    #endregion

    #region 04 Air Get SSR REQ/RES

    #region 04 Air Get SSR REQ
    public class AirSSRRequestDetail
    {
        public string Flight_Key { get; set; }
    }
    public class AirGetSSRReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string Search_Key { get; set; }
        public List<AirSSRRequestDetail> AirSSRRequestDetails { get; set; }
    }
    public class AirGetSSRRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public string Search_Key { get; set; }
        public List<AirSSRRequestDetail> AirSSRRequestDetails { get; set; }
    }
    #endregion

    #region 04 Air Get SSR RES
    public class SSRDetail
    {
        public List<int> ApplicablePaxTypes { get; set; }
        public string Currency_Code { get; set; }
        public string Flight_ID { get; set; }
        public int Leg_Index { get; set; }
        public string SSR_Code { get; set; }
        public string SSR_Key { get; set; }
        public int SSR_Status { get; set; }
        public int SSR_Type { get; set; }
        public string SSR_TypeDesc { get; set; }
        public string SSR_TypeName { get; set; }
        public int Segment_Id { get; set; }
        public bool Segment_Wise { get; set; }
        public int Total_Amount { get; set; }
    }
    public class SSRFlightDetail
    {
        public List<SSRDetail> SSRDetails { get; set; }
    }
    public class AirGetSSRRes
    {
        public ResponseHeader Response_Header { get; set; }
        public List<SSRFlightDetail> SSRFlightDetails { get; set; }
    }

    #endregion

    #endregion

    #region 05 AIR GET SEAT MAP REQ/RES

    #region 05 AIR GET SEAT MAP REQ
    //public class PAXDetail
    //{
    //    public int Pax_Id { get; set; }
    //    public int Pax_type { get; set; }
    //    public string Title { get; set; }
    //    public string First_Name { get; set; }
    //    public string Last_Name { get; set; }
    //    public int Gender { get; set; }
    //    public object Age { get; set; }
    //    public object DOB { get; set; }
    //    public object Passport_Number { get; set; }
    //    public object Passport_Issuing_Country { get; set; }
    //    public object Passport_Expiry { get; set; }
    //    public object Nationality { get; set; }
    //    public object FrequentFlyerDetails { get; set; }
    //}
    public class AirGetSeatMapReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string Search_Key { get; set; }
        public List<string> Flight_Keys { get; set; }
        public List<PAXDetail> PAX_Details { get; set; }
    }
    public class AirGetSeatMapRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public string Search_Key { get; set; }
        public List<string> Flight_Keys { get; set; }
        public List<PAXDetail> PAX_Details { get; set; }
    }
    #endregion

    #region 05 AIR GET SEAT MAP REQ/RES
    public class AirGetSeatMapRes
    {
        public List<AirGetSeatMapAirSeatMap> AirSeatMaps { get; set; }
        public ResponseHeader Response_Header { get; set; }
    }
    public class AirGetSeatMapSeatDetail
    {
        public List<int> ApplicablePaxTypes { get; set; }
        public string Currency_Code { get; set; }
        public string Flight_ID { get; set; }
        public int Leg_Index { get; set; }
        public object SSR_Code { get; set; }
        public string SSR_Key { get; set; }
        public int SSR_Status { get; set; }
        public int SSR_Type { get; set; }
        public string SSR_TypeDesc { get; set; }
        public string SSR_TypeName { get; set; }
        public int Segment_Id { get; set; }
        public bool Segment_Wise { get; set; }
        public decimal Total_Amount { get; set; }
    }
    public class AirGetSeatMapSeatRow
    {
        public List<AirGetSeatMapSeatDetail> Seat_Details { get; set; }
    }
    public class AirGetSeatMapSeatSegment
    {
        public int Leg_Index { get; set; }
        public List<AirGetSeatMapSeatRow> Seat_Row { get; set; }
    }
    public class AirGetSeatMapAirSeatMap
    {
        public string Flight_Id { get; set; }
        public List<AirGetSeatMapSeatSegment> Seat_Segments { get; set; }
    }

    #endregion

    #endregion

    #region 06 AIR_TEMP BOOKING REQ/RES
    #region 06 AIR_TEMP BOOKING REQ
    public class AirTempBookingReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string Customer_Mobile { get; set; }
        public string Passenger_Mobile { get; set; }
        public string WhatsAPP_Mobile { get; set; }
        public string Passenger_Email { get; set; }
        public List<PAXDetail> PAX_Details { get; set; }//public List<AirTempBookingPAXDetail> PAX_Details { get; set; }
        public bool GST { get; set; }
        public string GST_Number { get; set; }
        public string GST_HolderName { get; set; }
        public string GST_Address { get; set; }
        public List<AirTempBookingBookingFlightDetail> BookingFlightDetails { get; set; }
        public int CostCenterId { get; set; }
        public int ProjectId { get; set; }
        public string BookingRemark { get; set; }
        public int CorporateStatus { get; set; }
        public int CorporatePaymentMode { get; set; }
        public string MissedSavingReason { get; set; }
        public string CorpTripType { get; set; }
        public string CorpTripSubType { get; set; }
        public string TripRequestId { get; set; }
        public string BookingAlertIds { get; set; }
    }
    public class AirTempBookingRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public string Customer_Mobile { get; set; }
        public string Passenger_Mobile { get; set; }
        public string WhatsAPP_Mobile { get; set; }
        public string Passenger_Email { get; set; }
        public List<PAXDetail> PAX_Details { get; set; }
        public bool GST { get; set; }
        public string GST_Number { get; set; }
        public string GST_HolderName { get; set; }
        public string GST_Address { get; set; }
        public List<AirTempBookingBookingFlightDetail> BookingFlightDetails { get; set; }
        public int CostCenterId { get; set; }
        public int ProjectId { get; set; }
        public string BookingRemark { get; set; }
        public int CorporateStatus { get; set; }
        public int CorporatePaymentMode { get; set; }
        public string MissedSavingReason { get; set; }
        public string CorpTripType { get; set; }
        public string CorpTripSubType { get; set; }
        public string TripRequestId { get; set; }
        public string BookingAlertIds { get; set; }
    }
    public class AirTempBookingPAXDetail
    {
        public int Pax_Id { get; set; }
        public int Pax_type { get; set; }
        public string Title { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public int Gender { get; set; }
        public string Age { get; set; }
        public string DOB { get; set; }
        public string Passport_Number { get; set; }
        public string Passport_Issuing_Country { get; set; }
        public string Passport_Expiry { get; set; }
        public string Nationality { get; set; }
        public string FrequentFlyerDetails { get; set; }
    }
    public class AirTempBookingBookingFlightDetail
    {
        public string Search_Key { get; set; }
        public string Flight_Key { get; set; }
        public List<object> BookingSSRDetails { get; set; }
    }

    #endregion

    #region 06 AIR_TEMP BOOKING RES
    public class AirTempBookingBookingRes
    {
        public string Booking_RefNo { get; set; }
        public ResponseHeader Response_Header { get; set; }
    }
    #endregion
    #endregion

    #region 07 AIR_TICKETING REQ/RES
    #region 07 AIR_TICKETING REQ
    public class AirTicketingReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string Booking_RefNo { get; set; }
        public string Ticketing_Type { get; set; }
    }
    public class AirTicketingRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public string Booking_RefNo { get; set; }
        public string Ticketing_Type { get; set; }
    }
    #endregion

    #region 07 AIR_TICKETING RES
    public class AirTicketingRes
    {
        public List<AirlinePNRDetail> AirlinePNRDetails { get; set; }
        public string Booking_RefNo { get; set; }
        public ResponseHeader Response_Header { get; set; }
    }
    public class AirlinePNR
    {
        public string Airline_Code { get; set; }
        public string Airline_PNR { get; set; }
        public string CRS_Code { get; set; }
        public string CRS_PNR { get; set; }
        public string Record_Locator { get; set; }
        public string Supplier_RefNo { get; set; }
    }
    public class AirlinePNRDetail
    {
        public List<AirlinePNR> AirlinePNRs { get; set; }
        public string Failure_Remark { get; set; }
        public string Flight_Id { get; set; }
        public string Hold_Validity { get; set; }
        public string Status_Id { get; set; }
    }
    #endregion
    #endregion

    #region 08 AIR_HISTORY REQ/RES

    #region 08 AIR_HISTORY REQ
    public class AirHistoryReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string Fromdate { get; set; }
        public string Month { get; set; }
        public string Todate { get; set; }
        public string Type { get; set; }
        public string Year { get; set; }
    }
    public class AirHistoryRequset
    {
        public AuthHeader Auth_Header { get; set; }
        public string Fromdate { get; set; }
        public string Month { get; set; }
        public string Todate { get; set; }
        public string Type { get; set; }
        public string Year { get; set; }
    }
    #endregion

    #region 08 AIR_HISTORY RES
    public class AirHistoryRes
    {
        public ResponseHeader Response_Header { get; set; }
        public List<TicketHistory> TicketHistory { get; set; }
    }
    public class TicketHistoryTrip
    {
        public string AirlinesName { get; set; }
        public string BlockedExpiryDate { get; set; }
        public string Destination { get; set; }
        public string FlightId { get; set; }
        public string Origin { get; set; }
        public string Refno { get; set; }
        public string Remarks { get; set; }
        public int Status { get; set; }
        public string StatusDesc { get; set; }
        public object TicketDate { get; set; }
        public string TravelDate { get; set; }
    }
    public class TicketHistory
    {
        public string AirlinePNR { get; set; }
        public string BookingType { get; set; }
        public int CancellationCharges { get; set; }
        public string CustomerMobile { get; set; }
        public string CustomerName { get; set; }
        public int GatewayCharges { get; set; }
        public int GrossAmount { get; set; }
        public string InvoiceNumber { get; set; }
        public string OperatorId { get; set; }
        public string OperatorName { get; set; }
        public string PassengerName { get; set; }
        public int PromoAmount { get; set; }
        public string Refno { get; set; }
        public string ReqDate { get; set; }
        public int RetailerCommission { get; set; }
        public List<TicketHistoryTrip> TicketHistoryTrips { get; set; }
        public string TravelType { get; set; }
        public string TripDetails { get; set; }
    }
    #endregion

    #endregion

    #region 09 AIR_REPRINT REQ/RES
    #region 09 AIR_REPRINT REQ
    public class AirReprintReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string Booking_RefNo { get; set; }
        public string Airline_PNR { get; set; }
    }
    public class AirReprintRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public string Booking_RefNo { get; set; }
        public string Airline_PNR { get; set; }
    }
    #endregion

    #region 09 AIR_REPRINT RES
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class CancellationCharge
    {
        public int Applicablility { get; set; }
        public int DurationFrom { get; set; }
        public int DurationTo { get; set; }
        public int DurationTypeFrom { get; set; }
        public int DurationTypeTo { get; set; }
        public int OfflineServiceFee { get; set; }
        public int OnlineServiceFee { get; set; }
        public int PassengerType { get; set; }
        public string Remarks { get; set; }
        public bool Return_Flight { get; set; }
        public string Value { get; set; }
        public int ValueType { get; set; }
    }
    public class TicketDetail
    {
        public string Flight_Id { get; set; }
        public string Ticket_Number { get; set; }
    }
    public class PAXTicketDetail
    {
        public string Age { get; set; }
        public string DOB { get; set; }
        public List<Fare> Fares { get; set; }
        public string First_Name { get; set; }
        public object FrequentFlyerDetails { get; set; }
        public int Gender { get; set; }
        public string Last_Name { get; set; }
        public string Nationality { get; set; }
        public string Passport_Expiry { get; set; }
        public string Passport_Issuing_Country { get; set; }
        public string Passport_Number { get; set; }
        public int Pax_Id { get; set; }
        public int Pax_type { get; set; }
        public List<object> SSRDetails { get; set; }
        public List<TicketDetail> TicketDetails { get; set; }
        public string TicketStatus { get; set; }
        public string Title { get; set; }
    }
    public class AirPNRDetail
    {
        public string Airline_Code { get; set; }
        public object Airline_Name { get; set; }
        public string Airline_PNR { get; set; }
        public List<object> BookingChangeRequests { get; set; }
        public string CRS_Code { get; set; }
        public string CRS_PNR { get; set; }
        public object FailureRemark { get; set; }
        public List<Flight> Flights { get; set; }
        public int Gross_Amount { get; set; }
        public List<PAXTicketDetail> PAXTicketDetails { get; set; }
        public int Post_Markup { get; set; }
        public string Record_Locator { get; set; }
        public int RetailerPostMarkup { get; set; }
        public string Supplier_RefNo { get; set; }
        public string Ticket_Status_Desc { get; set; }
        public string Ticket_Status_Id { get; set; }
        public string TicketingDate { get; set; }
    }
    public class BookingPaymentDetail
    {
        public string Currency_Code { get; set; }
        public int Gateway_Charges { get; set; }
        public string PaymentConfirmation_Number { get; set; }
        public int Payment_Amount { get; set; }
        public int Payment_Mode { get; set; }
    }
    public class CompanyDetail
    {
        public string Address { get; set; }
        public string City { get; set; }
        public string CompanyName { get; set; }
        public string ContactPerson { get; set; }
        public string Country { get; set; }
        public string Email { get; set; }
        public string Fax { get; set; }
        public string GSTNo { get; set; }
        public string Logo { get; set; }
        public string MobileNo { get; set; }
        public string PANNo { get; set; }
        public string PhoneNo { get; set; }
        public string Pincode { get; set; }
        public string SACCode { get; set; }
        public string State { get; set; }
        public string Website { get; set; }
    }
    public class CustomerDetail
    {
        public string Customer_Email { get; set; }
        public string Customer_Mobile { get; set; }
        public string Customer_Name { get; set; }
        public string GSTAddress { get; set; }
        public string GSTHolderName { get; set; }
        public string GST_Number { get; set; }
    }
    public class RetailerDetail
    {
        public string BookedBy_Operator_Name { get; set; }
        public string Operator_Name { get; set; }
        public string Retailer_Address { get; set; }
        public string Retailer_Area { get; set; }
        public string Retailer_City { get; set; }
        public string Retailer_CompanyName { get; set; }
        public string Retailer_Email_Id { get; set; }
        public string Retailer_GSTno { get; set; }
        public string Retailer_Id { get; set; }
        public string Retailer_Landmark { get; set; }
        public string Retailer_Mobile_Number { get; set; }
        public string Retailer_Name { get; set; }
        public string Retailer_PANno { get; set; }
        public string Retailer_Pincode { get; set; }
        public string Retailer_State { get; set; }
        public string Sub_Retailer_CompanyName { get; set; }
        public string Sub_Retailer_Id { get; set; }
    }
    public class AirReprintRes
    {
        public int Adult_Count { get; set; }
        public List<AirPNRDetail> AirPNRDetails { get; set; }
        public string AirRequeryResponse_Key { get; set; }
        public int Biller_Id { get; set; }
        public List<BookingPaymentDetail> BookingPaymentDetail { get; set; }
        public string Booking_DateTime { get; set; }
        public string Booking_RefNo { get; set; }
        public int Booking_Type { get; set; }
        public int Child_Count { get; set; }
        public int Class_of_Travel { get; set; }
        public CompanyDetail CompanyDetail { get; set; }
        public int CorporatePaymentMode { get; set; }
        public CustomerDetail CustomerDetail { get; set; }
        public bool GST { get; set; }
        public string GSTIN { get; set; }
        public int Infant_Count { get; set; }
        public string Invoice_Number { get; set; }
        public string PAX_EmailId { get; set; }
        public string PAX_Mobile { get; set; }
        public string Remark { get; set; }
        public ResponseHeader Response_Header { get; set; }
        public RetailerDetail RetailerDetail { get; set; }
        public int Travel_Type { get; set; }
    }
    #endregion
    #endregion

    #region 10 AIR_TICKET CANCELLATION REQ/RES
    #region 10 AIR_TICKET CANCELLATION REQ
    public class AirTicketCancelDetail
    {
        public string FlightId { get; set; }
        public string PassengerId { get; set; }
        public string SegmentId { get; set; }
    }
    public class AirTicketCancellationReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public List<AirTicketCancelDetail> AirTicketCancelDetails { get; set; }
        public string Airline_PNR { get; set; }
        public string RefNo { get; set; }
        public string CancelCode { get; set; }
        public string ReqRemarks { get; set; }
        public int CancellationType { get; set; }
    }
    public class AirTicketCancellationRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public List<AirTicketCancelDetail> AirTicketCancelDetails { get; set; }
        public string Airline_PNR { get; set; }
        public string RefNo { get; set; }
        public string CancelCode { get; set; }
        public string ReqRemarks { get; set; }
        public int CancellationType { get; set; }
    }
    #endregion

    #region 10 AIR_TICKET CANCELLATION RES
    public class AirTicketCancellationRes
    {
        public ResponseHeader Response_Header { get; set; }
    }
    #endregion
    #endregion

    #region 11 AIR_LOWFARE REQ/RES
    #region 11 AIR_LOWFARE REQ
    public class AirLowFareReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string Destination { get; set; }
        public string Month { get; set; }
        public string Origin { get; set; }
        public int Year { get; set; }
    }
    public class AirLowFareRequest
    {
        public AuthHeader Auth_Header { get; set; }
        public string Destination { get; set; }
        public string Month { get; set; }
        public string Origin { get; set; }
        public int Year { get; set; }
    }
    #endregion

    #region 11 AIR_LOWFARE RES
    public class AirLowFareRes
    {
        public ResponseHeader Response_Header { get; set; }
    }
    #endregion
    #endregion

    #region GET BALANCE REQ/RES
    #region GET BALANCE REQ
    public class GetBalanceReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string RefNo { get; set; }
        public string Ticketing_Type { get; set; }
        public string ProductId { get; set; }
        public string EWalletID { get; set; }
    }
    public class GetBalanceRequset
    {
        public AuthHeader Auth_Header { get; set; }
        public string RefNo { get; set; }
        public string Ticketing_Type { get; set; }
        public string ProductId { get; set; }
        public string EWalletID { get; set; }
    }
    #endregion

    #region GET BALANCE RES
    public class GetBalanceRes
    {
        public int CreditBalance { get; set; }
        public int EffectiveBalance { get; set; }
        public int LienBalance { get; set; }
        public int ODAmount { get; set; }
        public ResponseHeader Response_Header { get; set; }
    }
    #endregion
    #endregion

    #region ADD PAYMENT REQ/RES
    #region ADD PAYMENT REQ/RES
    public class AddPaymentReq
    {
        //public AuthHeader Auth_Header { get; set; }
        public string ClientRefNo { get; set; }
        public string RefNo { get; set; }
        public int TransactionType { get; set; }
        public string ProductId { get; set; }
    }
    public class AddPaymentRequset
    {
        public AuthHeader Auth_Header { get; set; }
        public string ClientRefNo { get; set; }
        public string RefNo { get; set; }
        public int TransactionType { get; set; }
        public string ProductId { get; set; }
    }
    #endregion

    #region ADD PAYMENT REQ/RES
    public class AddPaymentRes
    {
        public int Amount { get; set; }
        public string PaymentID { get; set; }
        public ResponseHeader Response_Header { get; set; }
    }
        #endregion
        #endregion

    }
