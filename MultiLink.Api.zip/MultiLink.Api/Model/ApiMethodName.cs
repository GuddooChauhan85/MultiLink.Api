﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiLink.Api.Model
{
    public class ApiMethodName
    {
    }

    #region MULTILINK API METHOD NAME
    public class MultiLink_Method_Name
    {
        public const string Air_Search = "Air_Search";
        public const string Air_FareRule = "Air_FareRule";
        public const string Air_Reprice = "Air_Reprice";
        public const string Air_GetSSR = "Air_GetSSR";
        public const string Air_GetSeatMap = "Air_GetSeatMap";
        public const string Air_TempBooking = "Air_TempBooking";
        public const string Air_Ticketing = "Air_Ticketing";
        public const string Air_History = "Air_History";
        public const string Air_Reprint = "Air_Reprint";
        public const string Air_TicketCancellation = "Air_TicketCancellation";
        public const string Air_LowFare = "Air_LowFare";
        public const string GetBalance = "GetBalance";
        public const string AddPayment = "AddPayment";
    }
    #endregion
}
