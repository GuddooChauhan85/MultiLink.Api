﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace MultiLink.Api.Utility
{
    public class Util
    {
        #region HTTP GET/POST METHOD
        public string HttpPostWithPara(string url, string path, string payLoad)
        {
            string response = null;
            try
            {
                var client = new RestClient(url);
                var request = new RestRequest(path,Method.Post);

                System.Net.ServicePointManager.ServerCertificateValidationCallback = delegate (object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("application/json", payLoad, ParameterType.RequestBody);

                RestResponse iRestResponse = client.ExecuteAsync(request).Result;

                #region CREATE LOGGER
                if (Convert.ToString(Startup.AppSetting[AppSettings.IS_LOGGER]) == "1")
                {
                    Logger.Debug("Final Request: " + url+ path + "||" + payLoad);
                    Logger.Debug("Final Response: " + iRestResponse.Content);
                }
                #endregion

                response = iRestResponse.Content;
            }
            catch (Exception ex) { response = ex.Message; }
            return response;
        }
        #endregion
    }
}
