﻿using Microsoft.AspNetCore.Mvc;
using MultiLink.Api.Model;
using MultiLink.Api.ServiceProcess;
using System;
using System.Threading.Tasks;

namespace MultiLink.Api.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class MLFlightController : ControllerBase
    {

        #region 01 AIR SEARCH
        [Route("api/airSearch")]
        [HttpPost]
        public async Task<IActionResult> airSearch(AirSearchReq airSearchReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airSearch(airSearchReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 02 AIR_FARE_RULE
        [Route("api/airFareRule")]
        [HttpPost]
        public async Task<IActionResult> airFareRule(AirFareRuleReq airFareRuleReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airFareRule(airFareRuleReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 03 AIR REPRICE
        [Route("api/airReprice")]
        [HttpPost]
        public async Task<IActionResult> airReprice(AirRepriceReq airRepriceReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airReprice(airRepriceReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 04 AIR_GET SSR
        [Route("api/airGetSSR")]
        [HttpPost]
        public async Task<IActionResult> airGetSSR(AirGetSSRReq airGetSSRReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airGetSSR(airGetSSRReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 05 AIR GET SEAT MAP
        [Route("api/airGetSeatMap")]
        [HttpPost]
        public async Task<IActionResult> airGetSeatMap(AirGetSeatMapReq airGetSeatMapReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airGetSeatMap(airGetSeatMapReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 06 AIR_TEMP BOOKING
        [Route("api/airTempBooking")]
        [HttpPost]
        public async Task<IActionResult> airTempBooking(AirTempBookingReq airTempBookingReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airTempBooking(airTempBookingReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 07 AIR_TICKETING
        [Route("api/airTicketing")]
        [HttpPost]
        public async Task<IActionResult> airTicketing(AirTicketingReq airTicketingReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airTicketing(airTicketingReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 08 AIR_HISTORY
        [Route("api/airHistory")]
        [HttpPost]
        public async Task<IActionResult> airHistory(AirHistoryReq airHistoryReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airHistory(airHistoryReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 09 AIR_REPRINT
        [Route("api/airReprint")]
        [HttpPost]
        public async Task<IActionResult> airReprint(AirReprintReq airReprintReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airReprint(airReprintReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 10 AIR_TICKET CANCELLATION
        [Route("api/airTicketCancellation")]
        [HttpPost]
        public async Task<IActionResult> airTicketCancellation(AirTicketCancellationReq airTicketCancellationReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airTicketCancellation(airTicketCancellationReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 11 AIR_LOW FARE
        [Route("api/airLowFare")]
        [HttpPost]
        public async Task<IActionResult> airLowFare(AirLowFareReq airLowFareReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.airLowFare(airLowFareReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region 11 GET BALANCE
        [Route("api/getBalanceReq")]
        [HttpPost]
        public async Task<IActionResult> getBalance(GetBalanceReq getBalanceReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.getBalance(getBalanceReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion

        #region ADD PAYMENT
        [Route("api/addPayment")]
        [HttpPost]
        public async Task<IActionResult> addPayment(AddPaymentReq addPaymentReq)
        {
            var callService = new CallService();
            try
            {
                var serviceResponse = await callService.addPayment(addPaymentReq);
                return new OkObjectResult(serviceResponse);
            }
            catch (Exception ex)
            {
                return new OkObjectResult(ex.Message);
            }
        }
        #endregion
    }
}
